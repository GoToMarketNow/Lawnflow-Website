
  # LawnFlow.ai Marketing Site

  This is a code bundle for LawnFlow.ai Marketing Site. The original project is available at https://www.figma.com/design/DKYwUJKMi1jz3cdsHgOkmc/LawnFlow.ai-Marketing-Site.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  