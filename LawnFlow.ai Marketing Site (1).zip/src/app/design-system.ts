/**
 * LawnFlow.ai Design System
 * Sprint 0 - Foundations
 * 
 * This file documents the design tokens and guidelines for the LawnFlow.ai marketing site.
 */

export const designSystem = {
  // Color Palette
  colors: {
    primaryGreen: "#1F7A3A",
    darkGreen: "#0F3D1E",
    cream: "#F6F3EA",
    textPrimary: "#101828",
    textMuted: "#667085",
    border: "#EAECF0",
    accentBlue: "#2563EB",
  },

  // Typography Scale
  typography: {
    h1: {
      fontSize: "56px",
      lineHeight: "64px",
      usage: "Hero headlines, primary page titles",
    },
    h2: {
      fontSize: "40px",
      lineHeight: "48px",
      usage: "Section headings, major content blocks",
    },
    h3: {
      fontSize: "28px",
      lineHeight: "36px",
      usage: "Card titles, subsection headings",
    },
    body: {
      fontSize: "16px",
      lineHeight: "24px",
      usage: "Body text, descriptions",
    },
    small: {
      fontSize: "14px",
      lineHeight: "20px",
      usage: "Captions, labels, secondary text",
    },
  },

  // Spacing Scale (in pixels)
  spacing: {
    1: 4,
    2: 8,
    3: 12,
    4: 16,
    6: 24,
    8: 32,
    12: 48,
    16: 64,
    24: 96,
  },

  // Border Radius
  radius: {
    sm: 8,
    md: 12,
    lg: 16,
  },

  // Shadows
  shadows: {
    card: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)",
  },

  // Breakpoints
  breakpoints: {
    mobile: 390,
    tablet: 834,
    desktop: 1440,
  },

  // Component Guidelines
  components: {
    buttons: {
      variants: ["Primary", "Secondary", "Tertiary"],
      states: ["Default", "Hover", "Disabled"],
      sizes: ["Small", "Medium", "Large"],
    },
    cards: {
      types: ["Feature Card", "Content Card", "Testimonial Card"],
      padding: "24px",
      borderRadius: "12px",
    },
    sections: {
      verticalPadding: {
        mobile: "48px",
        tablet: "64px",
        desktop: "96px",
      },
    },
  },
};

// CSS Custom Property References
export const cssVars = {
  colors: {
    primaryGreen: "var(--primary-green)",
    darkGreen: "var(--dark-green)",
    cream: "var(--cream)",
    textPrimary: "var(--text-primary)",
    textMuted: "var(--text-muted)",
    border: "var(--border-color)",
    accentBlue: "var(--accent-blue)",
  },
  typography: {
    h1: "var(--text-h1)",
    h1Line: "var(--text-h1-line)",
    h2: "var(--text-h2)",
    h2Line: "var(--text-h2-line)",
    h3: "var(--text-h3)",
    h3Line: "var(--text-h3-line)",
    body: "var(--text-body)",
    bodyLine: "var(--text-body-line)",
    small: "var(--text-small)",
    smallLine: "var(--text-small-line)",
  },
  spacing: {
    1: "var(--spacing-1)",
    2: "var(--spacing-2)",
    3: "var(--spacing-3)",
    4: "var(--spacing-4)",
    6: "var(--spacing-6)",
    8: "var(--spacing-8)",
    12: "var(--spacing-12)",
    16: "var(--spacing-16)",
    24: "var(--spacing-24)",
  },
  radius: {
    sm: "var(--radius-sm)",
    md: "var(--radius-md)",
    lg: "var(--radius-lg)",
  },
  shadows: {
    card: "var(--shadow-card)",
  },
};
