import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { AgentsHero } from "@/app/components/agents/agents-hero";
import { AgentsGridSectionUpdated } from "@/app/components/agents/agents-grid-section-updated";
import { CollaborationDiagram } from "@/app/components/agents/collaboration-diagram";
import { HumanInLoopSection } from "@/app/components/agents/human-in-loop-section";
import { AgentsPageFooter } from "@/app/components/agents/agents-page-footer";

export function AgentsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <AgentsHero />
        <AgentsGridSectionUpdated />
        <CollaborationDiagram />
        <HumanInLoopSection />
        <AgentsPageFooter />
      </main>
      <Footer />
    </div>
  );
}