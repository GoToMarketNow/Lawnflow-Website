import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { ScreensHero } from "@/app/components/screens/screens-hero";
import { CommandCenterScreen } from "@/app/components/screens/command-center-screen";
import { QuoteCopilotScreen } from "@/app/components/screens/quote-copilot-screen";
import { ScheduleOptimizerScreen } from "@/app/components/screens/schedule-optimizer-screen";
import { CrewMobileScreenUpdated } from "@/app/components/screens/crew-mobile-screen-updated";
import { CustomerMobileScreenUpdated } from "@/app/components/screens/customer-mobile-screen-updated";
import { UserFlowsSection } from "@/app/components/screens/user-flows-section";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function ScreensPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ScreensHero />
        <CommandCenterScreen />
        <QuoteCopilotScreen />
        <ScheduleOptimizerScreen />
        <CrewMobileScreenUpdated />
        <CustomerMobileScreenUpdated />
        <UserFlowsSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}