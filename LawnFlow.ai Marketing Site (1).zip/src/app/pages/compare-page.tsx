import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { CompareHero } from "@/app/components/compare/compare-hero";
import { CompareIntro } from "@/app/components/compare/compare-intro";
import { CompareAccordion } from "@/app/components/compare/compare-accordion";
import { CompareCallout } from "@/app/components/compare/compare-callout";
import { CompareFinalCTA } from "@/app/components/compare/compare-final-cta";

export function ComparePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <CompareHero />
        <CompareIntro />
        <CompareAccordion />
        <CompareCallout />
        <CompareFinalCTA />
      </main>
      <Footer />
    </div>
  );
}
