import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { NewHeroSection } from "@/app/components/home/new-hero-section";
import { ProblemSection } from "@/app/components/home/problem-section";
import { SolutionSection } from "@/app/components/home/solution-section";
import { ThreeAudiencesSection } from "@/app/components/home/three-audiences-section";
import { MobileExperienceShowcase } from "@/app/components/home/mobile-experience-showcase";
import { CapabilitiesSection } from "@/app/components/home/capabilities-section";
import { OutcomesSection } from "@/app/components/home/outcomes-section";
import { CompetitiveCallout } from "@/app/components/home/competitive-callout";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <NewHeroSection />
        <ProblemSection />
        <SolutionSection />
        <ThreeAudiencesSection />
        <MobileExperienceShowcase />
        <CapabilitiesSection />
        <OutcomesSection />
        <CompetitiveCallout />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}