import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { ForCrewsHero } from "@/app/components/for-crews/for-crews-hero";
import { CrewDayPlanSection } from "@/app/components/for-crews/crew-day-plan-section";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function ForCrewsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ForCrewsHero />
        <CrewDayPlanSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}
