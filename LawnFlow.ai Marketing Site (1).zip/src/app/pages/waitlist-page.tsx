import { useState } from "react";
import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { WaitlistHero } from "@/app/components/waitlist/waitlist-hero";
import { WaitlistValueSection } from "@/app/components/waitlist/waitlist-value-section";
import { WaitlistForm } from "@/app/components/waitlist/waitlist-form";
import { WaitlistConfirmation } from "@/app/components/waitlist/waitlist-confirmation";
import { Button } from "@/app/components/ui/button";
import { ArrowRight } from "lucide-react";

export function WaitlistPage() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showStickyButton, setShowStickyButton] = useState(false);

  // Show sticky CTA on mobile when scrolled
  useState(() => {
    const handleScroll = () => {
      const formSection = document.getElementById("waitlist-form");
      if (formSection) {
        const rect = formSection.getBoundingClientRect();
        setShowStickyButton(rect.top > window.innerHeight);
      }
    };

    if (typeof window !== "undefined") {
      window.addEventListener("scroll", handleScroll);
      return () => window.removeEventListener("scroll", handleScroll);
    }
  });

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main>
          <WaitlistConfirmation onReset={() => setIsSubmitted(false)} />
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <WaitlistHero />

        {/* Two-Column Layout Section */}
        <section className="w-full py-8 md:py-12 lg:py-16 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-start">
              {/* Left: Value & Perks */}
              <div className="order-2 lg:order-1 lg:sticky lg:top-24">
                <WaitlistValueSection />
              </div>

              {/* Right: Form */}
              <div id="waitlist-form" className="order-1 lg:order-2">
                <WaitlistForm onSuccess={() => setIsSubmitted(true)} />
              </div>
            </div>
          </div>
        </section>

        {/* Sticky Mobile CTA */}
        {showStickyButton && (
          <div className="lg:hidden fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-[var(--border-color)] shadow-2xl z-40">
            <Button
              size="lg"
              className="w-full bg-[var(--primary-green)] hover:bg-[var(--dark-green)] text-white min-h-[56px]"
              onClick={() => {
                document
                  .getElementById("waitlist-form")
                  ?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              Join the Waitlist
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
