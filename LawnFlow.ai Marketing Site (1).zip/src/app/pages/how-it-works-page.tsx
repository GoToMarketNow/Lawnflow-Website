import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { HowItWorksHero } from "@/app/components/how-it-works/how-it-works-hero";
import { LifecycleTimeline } from "@/app/components/how-it-works/lifecycle-timeline";
import { TrustLadderSection } from "@/app/components/how-it-works/trust-ladder-section";
import { MeetAgentsCTA } from "@/app/components/how-it-works/meet-agents-cta";
import { ScreenPreviewsSection } from "@/app/components/how-it-works/screen-previews-section";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HowItWorksHero />
        <LifecycleTimeline />
        <TrustLadderSection />
        <MeetAgentsCTA />
        <ScreenPreviewsSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}