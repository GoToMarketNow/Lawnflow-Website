import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { ForCustomersHero } from "@/app/components/for-customers/for-customers-hero";
import { CustomerAppSection } from "@/app/components/for-customers/customer-app-section";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function ForCustomersPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ForCustomersHero />
        <CustomerAppSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}
