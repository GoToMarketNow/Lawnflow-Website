import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { CompetitiveMatrix } from "@/app/components/competitive/competitive-matrix";
import { PositioningSection } from "@/app/components/competitive/positioning-section";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function CompetitivePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        {/* Hero */}
        <section className="w-full py-12 md:py-16 lg:py-24 bg-gradient-to-b from-[var(--cream)] to-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <div className="text-center max-w-4xl mx-auto">
              <span className="inline-block px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-6">
                Competitive Analysis
              </span>
              <h1
                className="mb-6"
                style={{
                  fontSize: "var(--text-h1)",
                  lineHeight: "var(--text-h1-line)",
                  fontWeight: "var(--font-weight-bold)",
                  color: "var(--text-primary)",
                }}
              >
                Agentic Operations vs.<br />Traditional Field Service Software
              </h1>
              <p
                className="mb-8 max-w-2xl mx-auto"
                style={{
                  fontSize: "var(--text-body)",
                  lineHeight: "var(--text-body-line)",
                  color: "var(--text-muted)",
                }}
              >
                See how LawnFlow's AI agents compare to Yardbook, Jobber, Housecall Pro, Service
                Autopilot, and Aspire across 6 critical value dimensions.
              </p>
            </div>
          </div>
        </section>

        {/* Matrix */}
        <section className="w-full py-12 md:py-16 lg:py-20 bg-white">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <CompetitiveMatrix />
          </div>
        </section>

        {/* Positioning & Outcomes */}
        <PositioningSection />

        {/* Final CTA */}
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}
