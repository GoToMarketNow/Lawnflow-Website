import { Header } from "@/app/components/layout/header";
import { Footer } from "@/app/components/layout/footer";
import { ForOwnersHero } from "@/app/components/for-owners/for-owners-hero";
import { OwnerDashboardShowcase } from "@/app/components/for-owners/owner-dashboard-showcase";
import { BeforeAfterSection } from "@/app/components/for-owners/before-after-section";
import { FinalCTASection } from "@/app/components/home/final-cta-section";

export function ForOwnersPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ForOwnersHero />
        <OwnerDashboardShowcase />
        <BeforeAfterSection />
        <FinalCTASection />
      </main>
      <Footer />
    </div>
  );
}