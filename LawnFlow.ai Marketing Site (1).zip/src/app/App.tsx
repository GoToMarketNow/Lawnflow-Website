import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { HomePage } from "@/app/pages/home-page";
import { WaitlistPage } from "@/app/pages/waitlist-page";
import { HowItWorksPage } from "@/app/pages/how-it-works-page";
import { ForOwnersPage } from "@/app/pages/for-owners-page";
import { ForCrewsPage } from "@/app/pages/for-crews-page";
import { ForCustomersPage } from "@/app/pages/for-customers-page";
import { AgentsPage } from "@/app/pages/agents-page";
import { ScreensPage } from "@/app/pages/screens-page";
import { ComparePage } from "@/app/pages/compare-page";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/waitlist" element={<WaitlistPage />} />
        <Route path="/how-it-works" element={<HowItWorksPage />} />
        <Route path="/for-owners" element={<ForOwnersPage />} />
        <Route path="/for-crews" element={<ForCrewsPage />} />
        <Route path="/for-customers" element={<ForCustomersPage />} />
        <Route path="/agents" element={<AgentsPage />} />
        <Route path="/screens" element={<ScreensPage />} />
        <Route path="/compare" element={<ComparePage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}