import { Button } from "@/app/components/ui/button";
import { CheckCircle, Calendar, Mail, Sparkles, ArrowRight } from "lucide-react";

interface WaitlistConfirmationProps {
  onReset?: () => void;
}

export function WaitlistConfirmation({ onReset }: WaitlistConfirmationProps) {
  const nextSteps = [
    {
      icon: Mail,
      title: "Check your email",
      description:
        "We just sent a confirmation. Make sure to check your spam folder too.",
    },
    {
      icon: Calendar,
      title: "We'll reach out in 24 hours",
      description:
        "Our team will contact you to learn more about your business and confirm fit.",
    },
    {
      icon: Sparkles,
      title: "Get early access",
      description:
        "If you're selected for the cohort, we'll send your invite and get you onboarded.",
    },
  ];

  return (
    <section className="w-full py-12 md:py-16 lg:py-20 bg-gradient-to-b from-[var(--cream)] to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="bg-white rounded-2xl border border-[var(--border-color)] p-8 lg:p-12 shadow-xl text-center">
          {/* Success Icon */}
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-[var(--primary-green)] to-[var(--dark-green)] flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>

          {/* Headline */}
          <h1
            className="mb-4"
            style={{
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              lineHeight: "1.2",
              fontWeight: "var(--font-weight-medium)",
              color: "var(--text-primary)",
            }}
          >
            <span className="text-[var(--primary-green)]">You're in.</span>
          </h1>

          <p
            className="mb-8 max-w-xl mx-auto"
            style={{
              fontSize: "var(--text-body)",
              lineHeight: "var(--text-body-line)",
              color: "var(--text-muted)",
            }}
          >
            Thanks for joining the waitlist! We're excited to help you run a
            smarter, more profitable lawn care business.
          </p>

          {/* Next Steps */}
          <div className="mb-8">
            <h2
              className="mb-6 text-left"
              style={{
                fontSize: "var(--text-h3)",
                lineHeight: "var(--text-h3-line)",
                fontWeight: "var(--font-weight-medium)",
                color: "var(--text-primary)",
              }}
            >
              What happens next
            </h2>
            <div className="space-y-6">
              {nextSteps.map((step, index) => (
                <div
                  key={index}
                  className="flex items-start gap-4 text-left p-4 bg-gradient-to-br from-[var(--cream)] to-white rounded-lg border border-[var(--border-color)]"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-[var(--primary-green)]/10 flex items-center justify-center">
                    <step.icon className="w-6 h-6 text-[var(--primary-green)]" />
                  </div>
                  <div className="flex-1 min-w-0 pt-1">
                    <div
                      className="mb-1"
                      style={{
                        fontSize: "var(--text-body)",
                        fontWeight: "var(--font-weight-medium)",
                        color: "var(--text-primary)",
                      }}
                    >
                      {step.title}
                    </div>
                    <p
                      style={{
                        fontSize: "var(--text-small)",
                        lineHeight: "var(--text-small-line)",
                        color: "var(--text-muted)",
                      }}
                    >
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* While You Wait */}
          <div className="p-6 bg-gradient-to-br from-[var(--primary-green)]/5 to-[var(--primary-green)]/10 rounded-xl border border-[var(--primary-green)]/20 mb-8">
            <h3
              className="mb-2"
              style={{
                fontSize: "var(--text-body)",
                fontWeight: "var(--font-weight-medium)",
                color: "var(--text-primary)",
              }}
            >
              While you wait
            </h3>
            <p
              className="mb-4"
              style={{
                fontSize: "var(--text-small)",
                lineHeight: "var(--text-small-line)",
                color: "var(--text-muted)",
              }}
            >
              Learn how AI agents can transform your lawn care operations
            </p>
            <Button
              variant="outline"
              size="lg"
              className="border-[var(--primary-green)] text-[var(--primary-green)] hover:bg-[var(--primary-green)]/5 min-h-[48px]"
              onClick={() => {
                // Navigate to demo/explainer
                window.location.href = "/#features";
              }}
            >
              See How It Works
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>

          {/* Social Proof */}
          <div className="pt-6 border-t border-[var(--border-color)]">
            <div className="flex items-center justify-center gap-2 text-[var(--text-muted)]">
              <CheckCircle className="w-4 h-4 text-[var(--primary-green)]" />
              <span style={{ fontSize: "var(--text-small)" }}>
                You're #501 on the waitlist
              </span>
            </div>
          </div>

          {/* Debug: Reset Button (optional - for testing) */}
          {onReset && (
            <button
              onClick={onReset}
              className="mt-4 text-sm text-[var(--text-muted)] hover:text-[var(--primary-green)] underline"
            >
              Back to form (for testing)
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
