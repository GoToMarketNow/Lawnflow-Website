export function WaitlistHero() {
  return (
    <section className="w-full pt-20 pb-8 md:pt-24 md:pb-12 bg-gradient-to-b from-[var(--cream)] to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
        <div className="text-center max-w-3xl mx-auto">
          <h1
            className="mb-4"
            style={{
              fontSize: "clamp(2.25rem, 5vw, 3.5rem)",
              lineHeight: "1.15",
              fontWeight: "var(--font-weight-medium)",
              color: "var(--text-primary)",
            }}
          >
            Ready to{" "}
            <span className="text-[var(--primary-green)]">Profit, Grow and Automate?!</span>
          </h1>
          <p
            className="max-w-2xl mx-auto"
            style={{
              fontSize: "var(--text-body)",
              lineHeight: "var(--text-body-line)",
              color: "var(--text-muted)",
            }}
          >
            Early access for lawn care & landscaping operators who want admin
            off their plate and more profit per crew.
          </p>
        </div>
      </div>
    </section>
  );
}