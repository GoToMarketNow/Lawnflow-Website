import { CheckCircle, Sparkles, Users, Zap, Gift } from "lucide-react";

export function WaitlistValueSection() {
  const perks = [
    {
      icon: Gift,
      title: "Early Access Pricing",
      description: "Lock in founder rates before we launch publicly",
    },
    {
      icon: Users,
      title: "Personal Onboarding",
      description: "1-on-1 setup with our team, tailored to your operation",
    },
    {
      icon: Sparkles,
      title: "Shape the Product",
      description: "Your feedback directly influences what we build",
    },
    {
      icon: Zap,
      title: "Priority Support",
      description: "Direct line to our founders, not a support ticket queue",
    },
  ];

  const includes = [
    "24/7 AI lead response & quoting",
    "Smart scheduling & crew routing",
    "Automated invoicing & collections",
    "Customer communication & updates",
    "Analytics dashboard & reporting",
    "Mobile app for crews",
  ];

  return (
    <div className="space-y-8">
      {/* What You'll Get */}
      <div>
        <h3
          className="mb-4"
          style={{
            fontSize: "var(--text-h3)",
            lineHeight: "var(--text-h3-line)",
            fontWeight: "var(--font-weight-medium)",
            color: "var(--text-primary)",
          }}
        >
          What you'll get
        </h3>
        <div className="space-y-3">
          {includes.map((item, index) => (
            <div key={index} className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 flex-shrink-0 text-[var(--primary-green)] mt-0.5" />
              <span
                style={{
                  fontSize: "var(--text-body)",
                  lineHeight: "var(--text-body-line)",
                  color: "var(--text-primary)",
                }}
              >
                {item}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Early Access Perks */}
      <div>
        <h3
          className="mb-4"
          style={{
            fontSize: "var(--text-h3)",
            lineHeight: "var(--text-h3-line)",
            fontWeight: "var(--font-weight-medium)",
            color: "var(--text-primary)",
          }}
        >
          Early access perks
        </h3>
        <div className="space-y-4">
          {perks.map((perk, index) => (
            <div
              key={index}
              className="flex items-start gap-4 p-4 bg-gradient-to-br from-[var(--cream)] to-white rounded-lg border border-[var(--border-color)]"
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[var(--primary-green)]/10 flex items-center justify-center">
                <perk.icon className="w-5 h-5 text-[var(--primary-green)]" />
              </div>
              <div className="flex-1 min-w-0">
                <div
                  className="mb-1"
                  style={{
                    fontSize: "var(--text-body)",
                    fontWeight: "var(--font-weight-medium)",
                    color: "var(--text-primary)",
                  }}
                >
                  {perk.title}
                </div>
                <p
                  style={{
                    fontSize: "var(--text-small)",
                    lineHeight: "var(--text-small-line)",
                    color: "var(--text-muted)",
                  }}
                >
                  {perk.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Trust Badge */}
      <div className="p-6 bg-gradient-to-br from-[var(--primary-green)] to-[var(--dark-green)] rounded-xl text-white">
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-5 h-5" />
          <span
            style={{
              fontSize: "var(--text-body)",
              fontWeight: "var(--font-weight-medium)",
            }}
          >
            Join 500+ operators
          </span>
        </div>
        <p
          className="text-white/90"
          style={{
            fontSize: "var(--text-small)",
            lineHeight: "var(--text-small-line)",
          }}
        >
          Already on the waitlist from 47 states. We're selecting the first
          cohort of 50 businesses this month.
        </p>
      </div>
    </div>
  );
}
