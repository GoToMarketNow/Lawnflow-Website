import { useState } from "react";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { ShieldCheck, ArrowRight } from "lucide-react";

interface WaitlistFormProps {
  onSuccess: () => void;
}

export function WaitlistForm({ onSuccess }: WaitlistFormProps) {
  const [formData, setFormData] = useState({
    businessName: "",
    name: "",
    email: "",
    phone: "",
    city: "",
    state: "",
    teamSize: "",
    weeklyJobs: "",
    currentTools: "",
    topGoals: [] as string[],
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const teamSizeOptions = [
    { value: "1-2", label: "1–2 people" },
    { value: "3-5", label: "3–5 people" },
    { value: "6-10", label: "6–10 people" },
    { value: "11+", label: "11+ people" },
  ];

  const weeklyJobOptions = [
    { value: "1-10", label: "1–10 jobs/week" },
    { value: "11-25", label: "11–25 jobs/week" },
    { value: "26-50", label: "26–50 jobs/week" },
    { value: "51-100", label: "51–100 jobs/week" },
    { value: "100+", label: "100+ jobs/week" },
  ];

  const goalOptions = [
    "Win more leads",
    "Reduce admin",
    "Reduce collections",
    "Improve scheduling",
    "Crew comms",
    "Margin visibility",
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.businessName.trim()) {
      newErrors.businessName = "Business name is required";
    }

    if (!formData.name.trim()) {
      newErrors.name = "Your name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }

    if (!formData.city.trim()) {
      newErrors.city = "City is required";
    }

    if (!formData.state.trim()) {
      newErrors.state = "State is required";
    }

    if (!formData.teamSize) {
      newErrors.teamSize = "Please select your team size";
    }

    if (!formData.weeklyJobs) {
      newErrors.weeklyJobs = "Please select your weekly job volume";
    }

    if (formData.topGoals.length === 0) {
      newErrors.topGoals = "Please select at least one goal";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      // Focus first error
      const firstErrorField = Object.keys(errors)[0];
      document.getElementById(firstErrorField)?.focus();
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    console.log("Form submitted:", formData);
    setIsSubmitting(false);
    onSuccess();
  };

  const handleGoalToggle = (goal: string) => {
    setFormData((prev) => ({
      ...prev,
      topGoals: prev.topGoals.includes(goal)
        ? prev.topGoals.filter((g) => g !== goal)
        : [...prev.topGoals, goal],
    }));
    // Clear error when user makes selection
    if (errors.topGoals) {
      setErrors((prev) => ({ ...prev, topGoals: "" }));
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-[var(--border-color)] p-6 lg:p-8 shadow-xl">
      <div className="mb-6">
        <h2
          className="mb-2"
          style={{
            fontSize: "var(--text-h3)",
            lineHeight: "var(--text-h3-line)",
            fontWeight: "var(--font-weight-medium)",
            color: "var(--text-primary)",
          }}
        >
          Join the waitlist
        </h2>
        <p
          style={{
            fontSize: "var(--text-small)",
            lineHeight: "var(--text-small-line)",
            color: "var(--text-muted)",
          }}
        >
          Takes 2 minutes. We'll be in touch within 24 hours.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Business Name */}
        <div>
          <Label htmlFor="businessName" required>
            Business Name
          </Label>
          <Input
            id="businessName"
            type="text"
            value={formData.businessName}
            onChange={(e) => {
              setFormData({ ...formData, businessName: e.target.value });
              if (errors.businessName) {
                setErrors({ ...errors, businessName: "" });
              }
            }}
            placeholder="Green Horizons Lawn Care"
            error={errors.businessName}
            aria-required="true"
            aria-invalid={!!errors.businessName}
            aria-describedby={
              errors.businessName ? "businessName-error" : undefined
            }
          />
          {errors.businessName && (
            <p
              id="businessName-error"
              className="mt-1 text-sm text-red-600"
              role="alert"
            >
              {errors.businessName}
            </p>
          )}
        </div>

        {/* Name */}
        <div>
          <Label htmlFor="name" required>
            Your Name
          </Label>
          <Input
            id="name"
            type="text"
            value={formData.name}
            onChange={(e) => {
              setFormData({ ...formData, name: e.target.value });
              if (errors.name) {
                setErrors({ ...errors, name: "" });
              }
            }}
            placeholder="John Smith"
            error={errors.name}
            aria-required="true"
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? "name-error" : undefined}
          />
          {errors.name && (
            <p id="name-error" className="mt-1 text-sm text-red-600" role="alert">
              {errors.name}
            </p>
          )}
        </div>

        {/* Email */}
        <div>
          <Label htmlFor="email" required>
            Email
          </Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => {
              setFormData({ ...formData, email: e.target.value });
              if (errors.email) {
                setErrors({ ...errors, email: "" });
              }
            }}
            placeholder="john@greenhorizons.com"
            error={errors.email}
            aria-required="true"
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? "email-error" : undefined}
          />
          {errors.email && (
            <p id="email-error" className="mt-1 text-sm text-red-600" role="alert">
              {errors.email}
            </p>
          )}
        </div>

        {/* Phone (Optional) */}
        <div>
          <Label htmlFor="phone">Phone (Optional)</Label>
          <Input
            id="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) =>
              setFormData({ ...formData, phone: e.target.value })
            }
            placeholder="(555) 123-4567"
          />
        </div>

        {/* City & State */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="city" required>
              City
            </Label>
            <Input
              id="city"
              type="text"
              value={formData.city}
              onChange={(e) => {
                setFormData({ ...formData, city: e.target.value });
                if (errors.city) {
                  setErrors({ ...errors, city: "" });
                }
              }}
              placeholder="Austin"
              error={errors.city}
              aria-required="true"
              aria-invalid={!!errors.city}
              aria-describedby={errors.city ? "city-error" : undefined}
            />
            {errors.city && (
              <p id="city-error" className="mt-1 text-sm text-red-600" role="alert">
                {errors.city}
              </p>
            )}
          </div>
          <div>
            <Label htmlFor="state" required>
              State
            </Label>
            <Input
              id="state"
              type="text"
              value={formData.state}
              onChange={(e) => {
                setFormData({ ...formData, state: e.target.value });
                if (errors.state) {
                  setErrors({ ...errors, state: "" });
                }
              }}
              placeholder="TX"
              error={errors.state}
              maxLength={2}
              aria-required="true"
              aria-invalid={!!errors.state}
              aria-describedby={errors.state ? "state-error" : undefined}
            />
            {errors.state && (
              <p id="state-error" className="mt-1 text-sm text-red-600" role="alert">
                {errors.state}
              </p>
            )}
          </div>
        </div>

        {/* Team Size */}
        <div>
          <Label htmlFor="teamSize" required>
            Team Size
          </Label>
          <div className="grid grid-cols-2 gap-3 mt-2">
            {teamSizeOptions.map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => {
                  setFormData({ ...formData, teamSize: option.value });
                  if (errors.teamSize) {
                    setErrors({ ...errors, teamSize: "" });
                  }
                }}
                className={`min-h-[44px] px-4 py-3 rounded-lg border-2 transition-all text-sm font-medium ${
                  formData.teamSize === option.value
                    ? "border-[var(--primary-green)] bg-[var(--primary-green)]/5 text-[var(--primary-green)]"
                    : "border-[var(--border-color)] bg-white text-[var(--text-primary)] hover:border-[var(--primary-green)]/50"
                } ${errors.teamSize ? "border-red-500" : ""}`}
                aria-pressed={formData.teamSize === option.value}
                aria-label={`Team size: ${option.label}`}
              >
                {option.label}
              </button>
            ))}
          </div>
          {errors.teamSize && (
            <p className="mt-2 text-sm text-red-600" role="alert">
              {errors.teamSize}
            </p>
          )}
        </div>

        {/* Weekly Jobs */}
        <div>
          <Label htmlFor="weeklyJobs" required>
            Weekly Jobs
          </Label>
          <div className="grid grid-cols-2 gap-3 mt-2">
            {weeklyJobOptions.map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => {
                  setFormData({ ...formData, weeklyJobs: option.value });
                  if (errors.weeklyJobs) {
                    setErrors({ ...errors, weeklyJobs: "" });
                  }
                }}
                className={`min-h-[44px] px-4 py-3 rounded-lg border-2 transition-all text-sm font-medium ${
                  formData.weeklyJobs === option.value
                    ? "border-[var(--primary-green)] bg-[var(--primary-green)]/5 text-[var(--primary-green)]"
                    : "border-[var(--border-color)] bg-white text-[var(--text-primary)] hover:border-[var(--primary-green)]/50"
                } ${errors.weeklyJobs ? "border-red-500" : ""}`}
                aria-pressed={formData.weeklyJobs === option.value}
                aria-label={`Weekly jobs: ${option.label}`}
              >
                {option.label}
              </button>
            ))}
          </div>
          {errors.weeklyJobs && (
            <p className="mt-2 text-sm text-red-600" role="alert">
              {errors.weeklyJobs}
            </p>
          )}
        </div>

        {/* Current Tools */}
        <div>
          <Label htmlFor="currentTools">
            Current Tools (Optional)
          </Label>
          <Input
            id="currentTools"
            type="text"
            value={formData.currentTools}
            onChange={(e) =>
              setFormData({ ...formData, currentTools: e.target.value })
            }
            placeholder="e.g., Jobber, QuickBooks, Excel"
          />
          <p className="mt-1 text-xs text-[var(--text-muted)]">
            What are you using now for scheduling, invoicing, etc.?
          </p>
        </div>

        {/* Top Goals */}
        <div>
          <Label required>
            Top Goals (Select all that apply)
          </Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {goalOptions.map((goal) => (
              <button
                key={goal}
                type="button"
                onClick={() => handleGoalToggle(goal)}
                className={`min-h-[44px] px-4 py-2 rounded-full border-2 transition-all text-sm font-medium ${
                  formData.topGoals.includes(goal)
                    ? "border-[var(--primary-green)] bg-[var(--primary-green)] text-white"
                    : "border-[var(--border-color)] bg-white text-[var(--text-primary)] hover:border-[var(--primary-green)]/50"
                } ${errors.topGoals ? "border-red-500" : ""}`}
                aria-pressed={formData.topGoals.includes(goal)}
                aria-label={goal}
              >
                {goal}
              </button>
            ))}
          </div>
          {errors.topGoals && (
            <p className="mt-2 text-sm text-red-600" role="alert">
              {errors.topGoals}
            </p>
          )}
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          size="lg"
          className="w-full bg-[var(--primary-green)] hover:bg-[var(--dark-green)] text-white min-h-[48px]"
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            "Submitting..."
          ) : (
            <>
              Join the Waitlist
              <ArrowRight className="ml-2 w-5 h-5" />
            </>
          )}
        </Button>

        {/* Privacy Note */}
        <div className="flex items-start gap-3 p-4 bg-[var(--cream)] rounded-lg">
          <ShieldCheck className="w-5 h-5 flex-shrink-0 text-[var(--primary-green)] mt-0.5" />
          <p
            style={{
              fontSize: "var(--text-small)",
              lineHeight: "var(--text-small-line)",
              color: "var(--text-muted)",
            }}
          >
            We respect your privacy. Your info is never shared and you can
            unsubscribe anytime.
          </p>
        </div>
      </form>

      {/* What Happens Next */}
      <div className="mt-6 p-4 bg-gradient-to-br from-[var(--primary-green)]/5 to-[var(--primary-green)]/10 rounded-lg border border-[var(--primary-green)]/20">
        <h4
          className="mb-3"
          style={{
            fontSize: "var(--text-body)",
            fontWeight: "var(--font-weight-medium)",
            color: "var(--text-primary)",
          }}
        >
          What happens next?
        </h4>
        <ol className="space-y-2">
          <li className="flex items-start gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-[var(--primary-green)] text-white text-xs flex items-center justify-center font-medium">
              1
            </span>
            <span
              style={{
                fontSize: "var(--text-small)",
                lineHeight: "var(--text-small-line)",
                color: "var(--text-primary)",
              }}
            >
              We'll contact you within 24 hours to learn more
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-[var(--primary-green)] text-white text-xs flex items-center justify-center font-medium">
              2
            </span>
            <span
              style={{
                fontSize: "var(--text-small)",
                lineHeight: "var(--text-small-line)",
                color: "var(--text-primary)",
              }}
            >
              Confirm you're a good fit for the early cohort
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-[var(--primary-green)] text-white text-xs flex items-center justify-center font-medium">
              3
            </span>
            <span
              style={{
                fontSize: "var(--text-small)",
                lineHeight: "var(--text-small-line)",
                color: "var(--text-primary)",
              }}
            >
              Send you an invite to get started with LawnFlow
            </span>
          </li>
        </ol>
      </div>
    </div>
  );
}
